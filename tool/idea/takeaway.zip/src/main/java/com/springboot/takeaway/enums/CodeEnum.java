package com.springboot.takeaway.enums;

/**
 * 枚举接口
 *
 * @param <T>
 */
public interface CodeEnum<T> {

    T getCode();
}
