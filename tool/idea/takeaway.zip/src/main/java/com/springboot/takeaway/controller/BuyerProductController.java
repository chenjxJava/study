package com.springboot.takeaway.controller;

import com.springboot.takeaway.bean.ProductCategory;
import com.springboot.takeaway.bean.ProductInfo;
import com.springboot.takeaway.service.CategoryService;
import com.springboot.takeaway.service.ProductService;
import com.springboot.takeaway.utils.ResultVOUtil;
import com.springboot.takeaway.vo.ProductInfoVO;
import com.springboot.takeaway.vo.ProductVO;
import com.springboot.takeaway.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/buyer/product")
public class BuyerProductController {

    @Autowired
    ProductService productService;

    @Autowired
    CategoryService categoryService;

    @RequestMapping("/list")
    public ResultVO list() {
        //1.查询所有上架商品
        List<ProductInfo> infoList = productService.findUpAll();
        //2.查询所有上架商品的类目
        List<Integer> categoryTypes = infoList.stream().map(
                e -> e.getCategoryType()).
                collect(Collectors.toList());
        List<ProductCategory> categories = categoryService.findByCategoryTypeIn(categoryTypes);
        //3.组装数据
        //遍历商品类目(根据类型组装数据)
        List<ProductVO> productVOList = new ArrayList<>();
        for (ProductCategory category : categories) {
            ProductVO productVO = new ProductVO();
            // productVO.setCategoryType(category.getCategoryType());
            // productVO.setCategoryName(category.getCategoryName());
            BeanUtils.copyProperties(category, productVO);

            //封装商品详情数据
            List<ProductInfoVO> productInfoVOList = new ArrayList<>();
            for (ProductInfo productInfo : infoList) {
                //上架商品跟类目匹配判断
                if (productInfo.getCategoryType().equals(category.getCategoryType())) {
                    ProductInfoVO productInfoVO = new ProductInfoVO();
                    BeanUtils.copyProperties(productInfo, productInfoVO);
                    productInfoVOList.add(productInfoVO);
                }

            }
            productVO.setProductInfoVOList(productInfoVOList);
            productVOList.add(productVO);
        }
        return ResultVOUtil.success(productVOList);
    }
}
