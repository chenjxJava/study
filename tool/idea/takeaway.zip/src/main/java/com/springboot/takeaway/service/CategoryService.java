package com.springboot.takeaway.service;

import com.springboot.takeaway.bean.ProductCategory;

import java.util.List;

public interface CategoryService {
    /**
     * 根据id查询一条类目
     *
     * @param categoryId
     * @return
     */
    ProductCategory findOne(Integer categoryId);

    /**
     * 查询所有类目
     *
     * @return
     */
    List<ProductCategory> findAll();

    /**
     * 根据类型list查询类目
     *
     * @param categoryType
     * @return
     */
    List<ProductCategory> findByCategoryTypeIn(List<Integer> categoryType);

    /**
     * 添加保存类目
     *
     * @param productCategory
     * @return
     */
    ProductCategory save(ProductCategory productCategory);
}
