package com.springboot.takeaway.exception;

import com.springboot.takeaway.enums.ResultEnum;
import lombok.Getter;

public class TakeawayException extends RuntimeException {

    @Getter
    private Integer code;

    private String message;

    public TakeawayException(ResultEnum resultEnum) {
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
    }
}
