package com.springboot.takeaway.bean;

import com.springboot.takeaway.enums.OrderStatusEnum;
import com.springboot.takeaway.enums.PayStatusEnum;
import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 订单主表
 */
@Data
@Entity
@DynamicUpdate
public class OrderMaster {

    /**
     * 订单id
     */
    @Id
    private String orderId;

    /**
     * 买家名字
     */
    private String buyerName;

    /**
     * 买家电话
     */
    private String buyerPhone;

    /**
     * 买家地址
     */
    private String buyerAddress;

    /**
     * 买家微信id
     */
    private String buyerOpenid;

    /**
     * 订单金额
     */
    private BigDecimal orderAmount;

    /**
     * 订单状态
     */
    private Integer orderStatus = OrderStatusEnum.NEW.getCode();

    /**
     * 支付状态
     */
    private Integer payStatus = PayStatusEnum.WAIT.getCode();

    private Date createTime;

    private Date updateTime;

    //@Transient可以将detail跟master进行关联,但是数据库中没有orderDetailList的字段
    //可以使用@transient进行过滤,不过这种方案不太好,
    //因为bean中需要跟数据库交互,又要传输容易混杂,可以定义单独的dto(data transfer object)
    //private List<OrderDetail> orderDetailList;
}
