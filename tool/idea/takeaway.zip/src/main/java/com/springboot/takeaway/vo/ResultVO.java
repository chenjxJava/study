package com.springboot.takeaway.vo;

import lombok.Data;

/**
 * 返回结果最外层对象(第一层)
 *
 * @param <T>
 */
@Data
public class ResultVO<T> {

    private Integer code;

    private String msg;

    private T data;
}
