package com.springboot.takeaway.converter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.springboot.takeaway.bean.OrderDetail;
import com.springboot.takeaway.dto.OrderDTO;
import com.springboot.takeaway.enums.ResultEnum;
import com.springboot.takeaway.exception.TakeawayException;
import com.springboot.takeaway.form.OrderForm;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class OrderForm2OrderDTOConverter {

    public static OrderDTO convert(OrderForm orderForm) {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setBuyerName(orderForm.getName());
        orderDTO.setBuyerOpenid(orderForm.getOpenid());
        orderDTO.setBuyerAddress(orderForm.getAddress());
        orderDTO.setBuyerPhone(orderForm.getPhone());

        try {
            List<OrderDetail> orderDetailList = new Gson().fromJson(orderForm.getItems(),
                    new TypeToken<List<OrderDetail>>() {
                    }.getType());
            orderDTO.setOrderDetailList(orderDetailList);
        } catch (Exception e) {
            log.error("【对象转换】错误, string={}", orderForm.getItems());
            throw new TakeawayException(ResultEnum.PARAM_CONVERT_ERROR);
        }
        return orderDTO;

    }
}
