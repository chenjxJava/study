package com.springboot.takeaway.utils;

import java.util.Random;

public class KeyUtil {

    public static String generateKey() {
        Random random = new Random();
        int num = random.nextInt(90000) + 10000;
        long timeMillis = System.currentTimeMillis();
        return timeMillis + String.valueOf(num);
    }
}
