package com.springboot.takeaway.utils;

import com.springboot.takeaway.vo.ResultVO;

public class ResultVOUtil {

    public static ResultVO success(Object data) {
        ResultVO ResultVO = new ResultVO();
        ResultVO.setCode(10);
        ResultVO.setMsg("成功");
        ResultVO.setData(data);
        return ResultVO;
    }

    public static ResultVO success() {
        return success(null);
    }

    public static ResultVO error(Integer code, String msg) {
        ResultVO ResultVO = new ResultVO();
        ResultVO.setCode(code);
        ResultVO.setMsg(msg);
        return ResultVO;
    }
}
