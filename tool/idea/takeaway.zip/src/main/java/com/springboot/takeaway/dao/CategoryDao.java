package com.springboot.takeaway.dao;

import com.springboot.takeaway.bean.ProductCategory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoryDao extends JpaRepository<ProductCategory, Integer> {

    /**
     * 根据类型集合查询类目集合
     * @param categoryTypeList
     * @return
     */
    List<ProductCategory> findByCategoryTypeIn(List<Integer> categoryTypeList);
}
