package com.springboot.takeaway.dao;

import com.springboot.takeaway.bean.OrderMaster;
import com.springboot.takeaway.enums.OrderStatusEnum;
import com.springboot.takeaway.enums.PayStatusEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderMasterDaoTest {

    public static final String BUYER_OPENID = "123321";
    @Autowired
    OrderMasterDao dao;

    @Test
    public void saveTest() {
        OrderMaster master = new OrderMaster();
        master.setBuyerAddress("武汉");
        master.setBuyerName("张三");
        master.setBuyerOpenid(BUYER_OPENID);
        master.setBuyerPhone("13888888888");
        master.setOrderAmount(new BigDecimal(5.88));
        master.setOrderId("654321");
        master.setOrderStatus(OrderStatusEnum.NEW.getCode());
        master.setPayStatus(PayStatusEnum.WAIT.getCode());
        OrderMaster result = dao.save(master);
        assertEquals("654321", result.getOrderId());
    }

    @Test
    public void findByBuyerOpenid() {
        PageRequest request = new PageRequest(0, 2);
        Page<OrderMaster> result = dao.findByBuyerOpenid(BUYER_OPENID, request);
        assertNotNull(result);
    }

}