package com.springboot.takeaway.dao;

import com.springboot.takeaway.bean.ProductInfo;
import com.springboot.takeaway.enums.ProductStatusEnum;
import com.springboot.takeaway.utils.KeyUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductDaoTest {

    @Autowired
    ProductDao dao;

    @Test
    public void saveTest() {
        ProductInfo productInfo = new ProductInfo();
        productInfo.setProductId(KeyUtil.generateKey());
        productInfo.setProductStock(100);
        productInfo.setCategoryType(3);
        productInfo.setProductStatus(ProductStatusEnum.UP.getCode());
        productInfo.setProductIcon("xxx.jpg");
        productInfo.setProductName("凤梨");
        productInfo.setProductDescription("大菠萝很好吃");
        productInfo.setProductPrice(new BigDecimal(6.78));
        ProductInfo result = dao.save(productInfo);
        Assert.assertNotNull(result);
    }

    @Test
    public void findByProductStatus() {
        List<ProductInfo> list = dao.findByProductStatus(ProductStatusEnum.UP.getCode());
        Assert.assertNotEquals(0, list.size());
    }
}