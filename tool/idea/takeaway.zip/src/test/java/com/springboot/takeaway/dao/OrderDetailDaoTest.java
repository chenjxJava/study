package com.springboot.takeaway.dao;

import com.springboot.takeaway.bean.OrderDetail;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderDetailDaoTest {

    @Autowired
    OrderDetailDao dao;

    @Test
    public void saveTest() {
        OrderDetail detail = new OrderDetail();
        detail.setDetailId("123");
        detail.setOrderId("654321");
        detail.setProductIcon("xxx.jpg");
        detail.setProductId("aaa");
        detail.setProductName("八宝粥");
        detail.setProductPrice(new BigDecimal(6.78));
        detail.setProductQuantity(2);
        OrderDetail result = dao.save(detail);
        assertNotNull(result);
    }

    @Test
    public void findByOrderId() {
        List<OrderDetail> result = dao.findByOrderId("654321");
        assertNotEquals(0, result.size());
    }

}