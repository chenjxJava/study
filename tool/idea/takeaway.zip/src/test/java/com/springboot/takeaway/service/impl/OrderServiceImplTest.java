package com.springboot.takeaway.service.impl;

import com.springboot.takeaway.bean.OrderDetail;
import com.springboot.takeaway.dto.OrderDTO;
import com.springboot.takeaway.enums.OrderStatusEnum;
import com.springboot.takeaway.enums.PayStatusEnum;
import com.springboot.takeaway.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderServiceImplTest {

    public static final String BUYER_OPENID = "aaa";
    public static final String ORDER_ID = "152228875006614621";
    @Autowired
    OrderService orderService;

    @Test
    public void create() {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setBuyerName("小白龙");
        orderDTO.setBuyerAddress("武汉");
        orderDTO.setBuyerPhone("13888888888");
        orderDTO.setBuyerOpenid(BUYER_OPENID);

        //购物车
        List<OrderDetail> orderDetailList = new ArrayList<>();
        OrderDetail o1 = new OrderDetail();
        o1.setProductId("152220065502244859");
        o1.setProductQuantity(60);

        OrderDetail o2 = new OrderDetail();
        o2.setProductId("152220184220414791");
        o2.setProductQuantity(60);

        orderDetailList.add(o2);
        orderDetailList.add(o1);
        orderDTO.setOrderDetailList(orderDetailList);

        OrderDTO result = orderService.create(orderDTO);

        log.info("[订单添加] result={}", result);
    }

    @Test
    public void findOne() {
        OrderDTO orderDTO = orderService.findOne(ORDER_ID);
        log.info("[查询单个订单] result={}", orderDTO);
        assertNotNull(orderDTO);
    }

    @Test
    public void findList() {
        Page<OrderDTO> orderDTOPage = orderService.findList(BUYER_OPENID,
                new PageRequest(0, 2));
        assertNotEquals(0, orderDTOPage.getTotalElements());
    }

    @Test
    public void cancel() {
        OrderDTO orderDTO = orderService.findOne(ORDER_ID);
        OrderDTO result = orderService.cancel(orderDTO);
        assertEquals(OrderStatusEnum.CANCEL.getCode(), result.getOrderStatus());
    }

    @Test
    public void finish() {
        OrderDTO orderDTO = orderService.findOne(ORDER_ID);
        OrderDTO result = orderService.finish(orderDTO);
        assertEquals(OrderStatusEnum.FINISH.getCode(), result.getOrderStatus());
    }

    @Test
    public void pay() {
        OrderDTO orderDTO = orderService.findOne(ORDER_ID);
        OrderDTO result = orderService.pay(orderDTO);
        assertEquals(PayStatusEnum.SUCCESS.getCode(), result.getPayStatus());
    }

    @Test
    public void list() {
        Page<OrderDTO> orderDTOPage = orderService.findList(new PageRequest(0, 2));
        assertTrue("分页查询订单列表错误", orderDTOPage.getTotalElements() > 0);
    }

}