package com.springboot.takeaway.service;

import com.springboot.takeaway.bean.ProductCategory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertNotNull;


@RunWith(SpringRunner.class)
@SpringBootTest
public class CategoryServiceTest {

    @Autowired
    CategoryService service;

    @Test
    public void findOne() {
        ProductCategory result = service.findOne(3);
        Assert.assertNotNull(result);
    }

    @Test
    public void findAll() {
        List<ProductCategory> list = service.findAll();
        Assert.assertNotEquals(0, list.size());
    }

    @Test
    public void findByCategoryTypeIn() {
        List<ProductCategory> categories = service.findByCategoryTypeIn(Arrays.asList(1, 3));
        Assert.assertNotEquals(0, categories.size());
    }

    @Test
    public void save() {
        ProductCategory category = new ProductCategory();
        category.setCategoryType(3);
        category.setCategoryName("水果甜品");
        ProductCategory result = service.save(category);
        assertNotNull(result);
    }
}