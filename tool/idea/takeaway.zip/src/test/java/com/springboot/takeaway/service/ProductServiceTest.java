package com.springboot.takeaway.service;

import com.springboot.takeaway.bean.ProductInfo;
import com.springboot.takeaway.enums.ProductStatusEnum;
import com.springboot.takeaway.utils.KeyUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductServiceTest {

    @Autowired
    ProductService service;

    @Test
    public void findOne() {
        ProductInfo result = service.findOne("152220065502244859");
        assertEquals("152220065502244859", result.getProductId());
    }

    @Test
    public void findUpAll() {
        List<ProductInfo> list = service.findUpAll();
        assertNotEquals(0, list.size());
    }

    @Test
    public void findAll() {
        PageRequest pageRequest = new PageRequest(0, 2);
        Page<ProductInfo> all = service.findAll(pageRequest);
        assertNotEquals(0, all.getContent());
    }

    @Test
    public void save() {
        ProductInfo productInfo = new ProductInfo();
        productInfo.setProductId(KeyUtil.generateKey());
        productInfo.setProductStock(50);
        productInfo.setCategoryType(2);
        productInfo.setProductStatus(ProductStatusEnum.UP.getCode());
        productInfo.setProductIcon("xxx.jpg");
        productInfo.setProductName("叉烧饭");
        productInfo.setProductDescription("叉烧饭很多油");
        productInfo.setProductPrice(new BigDecimal(15.55));
        ProductInfo result = service.save(productInfo);
        Assert.assertNotNull(result);
    }

    @Test
    public void onSale() {
        ProductInfo result = service.onSale("152220065502244859");
        Assert.assertEquals(ProductStatusEnum.UP, result.getProductStatusEnum());
    }

    @Test
    public void offSale() {
        ProductInfo result = service.offSale("152220065502244859");
        Assert.assertEquals(ProductStatusEnum.DOWN, result.getProductStatusEnum());
    }
}