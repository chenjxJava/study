package com.springboot.takeaway.dao;

import com.springboot.takeaway.bean.ProductCategory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CategoryDaoTest {

    @Autowired
    CategoryDao dao;

    @Test
    public void saveTest() {
        ProductCategory category = new ProductCategory();
        category.setCategoryType(2);
        category.setCategoryName("简单便当");
        ProductCategory result = dao.save(category);
        assertNotNull(result);
    }

    @Test
    public void findOneTest() {
        ProductCategory result = dao.findOne(3);
        assertEquals(new Integer(3), result.getCategoryId());
    }

    @Test
    public void updateTest() {
        ProductCategory category = dao.findOne(3);
        category.setCategoryName("炸鸡啤酒");
        ProductCategory result = dao.save(category);
        assertNotNull(result);
    }

    @Test
    public void findByCategoryTypeInTest() {
        List<Integer> list = Arrays.asList(1, 3);
        List<ProductCategory> categories = dao.findByCategoryTypeIn(list);
        assertEquals(0, categories.size());
    }


}