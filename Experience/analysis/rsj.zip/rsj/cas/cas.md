# 一、cas单点登入

### 1.cas server war包

##### 1.1 git clone项目 (build package) 

​	

##### 1.2 默认帐号名和密码：casuser/Mellon

### 2.@#$Chenjx234