package com.doone.core.util;

/**
 * ���ó����ࡣ
 * 
 * @author chenjianhong
 */
public abstract class Constants {

	/** Ĭ��ʱ���ʽ **/
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

	/** DateĬ��ʱ�� **/
	public static final String DATE_TIMEZONE = "GMT+8";

	/** UTF-8�ַ��� **/
	public static final String CHARSET_UTF8 = "UTF-8";

	/** GBK�ַ��� **/
	public static final String CHARSET_GBK = "GBK";

	/** JSON Ӧ��ʽ */
	public static final String FORMAT_JSON = "json";
	/** XML Ӧ��ʽ */
	public static final String FORMAT_XML = "xml";

	/** MD5ǩ����ʽ */
	public static final String SIGN_METHOD_MD5 = "md5";
	/** HMACǩ����ʽ */
	public static final String SIGN_METHOD_HMAC = "hmac";

	/** ��Ӧ���� */
	public static final String ACCEPT_ENCODING = "Accept-Encoding";
	public static final String CONTENT_ENCODING = "Content-Encoding";
	public static final String CONTENT_ENCODING_GZIP = "gzip";

}
